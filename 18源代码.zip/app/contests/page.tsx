import { Suspense } from "react";
import { auth, signOut } from "@/auth";
import { TopNavBar } from "@/app/components/TopNavBar";
import { appRoutes } from "@/lib/route";
import { ContestsFilter } from "@/components/contests-filter";
import { OngoingContests } from "@/components/ongoing-contests";
import { CustomSelect } from "@/components/custom-select";
import { prisma } from "@/lib/prisma";
import ContestsPageClient from "./contests-client";

async function loadContests() {
  const contests = await prisma.contest.findMany({
    orderBy: { startTime: "desc" },
  });
  return contests;
}

export default async function ContestsPage() {
  const session = await auth();
  const contests = await loadContests();

  async function handleSignOut(_formData: FormData) {
    "use server";
    await signOut({ redirectTo: "/" });
  }

  // 转换为客户端可序列化的格式
  const serializedContests = contests.map((c) => ({
    ...c,
    startTime: c.startTime.toISOString(),
    endTime: c.endTime.toISOString(),
  }));

  return (
    <div className="min-h-screen bg-background">
      <TopNavBar
        routes={appRoutes}
        signedIn={Boolean(session?.user)}
        userId={session?.user?.id}
        userName={session?.user?.name}
        onSignOut={session?.user ? handleSignOut : undefined}
      />

      <div className="pt-12">
        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight text-foreground">
              比赛中心
            </h1>
            <p className="mt-2 text-sm text-muted">
              参加各类编程竞赛，与全球编程爱好者同场竞技
            </p>
          </div>

          <div className="space-y-6">
            {/* 进行中的比赛 */}
            <OngoingContests contests={serializedContests} />

            {/* 使用客户端组件处理筛选和排序 */}
            <Suspense
              fallback={<div className="text-center text-muted">加载中...</div>}
            >
              <ContestsPageClient contests={serializedContests} />
            </Suspense>
          </div>
        </div>
      </div>
    </div>
  );
}
